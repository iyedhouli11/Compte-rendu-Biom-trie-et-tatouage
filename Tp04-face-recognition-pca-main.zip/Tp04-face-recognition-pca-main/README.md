# TP04 — Reconnaissance Faciale par PCA (Eigenfaces) et Viola-Jones

## Questions d'Analyse

### Q1 — Pourquoi PCA nécessite un bon alignement des visages ?

La PCA calcule une moyenne pixel par pixel sur toutes les images.
Si les visages ne sont pas alignés (yeux et nez à des positions
différentes d'une image à l'autre), le visage moyen devient flou
et les eigenfaces capturent des décalages géométriques au lieu
de capturer les vraies différences entre les identités.
La distance euclidienne est alors biaisée et la reconnaissance
devient peu fiable.

---

### Q2 — Que se passe-t-il si k est trop faible ?

Avec peu de composantes, l'espace PCA sous-représente les visages.
Des personnes différentes peuvent avoir des projections très proches
dans cet espace réduit, ce qui provoque des confusions entre identités.
On observe un taux de reconnaissance faible et beaucoup de
fausses acceptations.

Dans notre expérimentation :
- k=3 → variance expliquée = 59.6% → distance faible mais peu fiable
- k=5 → variance expliquée = 78.9% → meilleure séparation
- k=7 → variance expliquée = 92.0% → résultats les plus fiables

---

### Q3 — Que se passe-t-il si k est trop élevé ?

Trop de composantes intègrent du bruit (les dernières eigenfaces
représentent des variations non discriminantes comme le bruit
de l'image). La distance euclidienne est alors "polluée" par
ces dimensions inutiles, ce qui dégrade la reconnaissance.
Le temps de calcul augmente également sans gain de précision.

Règle pratique : choisir k pour expliquer entre 85% et 95%
de la variance totale.

---

### Q4 — Pourquoi la distance Euclidienne est adaptée dans l'espace PCA ?

Les eigenfaces forment une base orthonormée. Dans cet espace,
les axes sont indépendants et décorrélés. Chaque composante
contribue de façon égale et significative à la distance.
La distance euclidienne est donc un estimateur fidèle de la
dissimilarité entre deux visages projetés.

---

### Q5 — Quelles sont les limites d'Eigenfaces face aux variations d'illumination ?

La PCA opère directement sur les intensités brutes des pixels.
Une variation d'éclairage modifie fortement ces valeurs, même
pour le même visage. Un visage sous une lumière différente peut
se retrouver très loin de sa projection d'entraînement dans
l'espace PCA, provoquant un faux rejet.

Solutions possibles :
- Normalisation par égalisation d'histogramme avant la PCA
- Utilisation de descripteurs invariants à l'illumination (LBP)
- Méthodes supervisées (Fisherfaces, LDA) qui maximisent
  la séparation inter-classes plutôt que la variance globale
- Réseaux de neurones profonds (CNN) pour une robustesse totale

---

## Structure du projet
```
tp4/
├── dataset/
│   ├── person1/        ← images d'entraînement Cristiano (5 images)
│   └── person2/        ← images d'entraînement Messi    (5 images)
├── test/
│   ├── test_cristiano.jpg
│   ├── test_messi.jpg
│   └── test_inconnu.jpg
└── TP4.ipynb
```

## Dépendances
```bash
pip install opencv-python numpy matplotlib
```
